<?php
/* ############################################################ *\
 ----------------------------------------------------------------
@package	Jcow Social Networking Script.
@copyright	Copyright (C) 2009 - 2010 jcow.net.  All Rights Reserved.
@license	see http://jcow.net/license
 ----------------------------------------------------------------
\* ############################################################ */



function photos_u_menu(&$tab_menu,$page) {
	$tab_menu[] = array(
		'name'=>'Photos',
		'type'=>'tab',
		'path'=>'photos/liststories/page_'.$page['id']
		);
}

function photos_page_menu(&$tab_menu,$page) {
	$tab_menu[] = array(
		'name'=>'Photos',
		'type'=>'tab',
		'path'=>'photos/liststories/page_'.$page['id']
		);
}

/* owner,connected,everyone */
function photos_quick_share() {
	return array(
		'u' => array('access'=>'owner'),
		'page' => array('access'=>'connected')
		);
}