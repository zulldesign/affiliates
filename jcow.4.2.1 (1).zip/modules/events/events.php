<?php
/* ############################################################ *\
Copyright (C) 2009 - 2010 jcow.net.  All Rights Reserved.
------------------------------------------------------------------------
The contents of this file are subject to the Common Public Attribution
License Version 1.0. (the "License"); you may not use this file except in
compliance with the License. You may obtain a copy of the License at
http://www.jcow.net/celicense. The License is based on the Mozilla Public
License Version 1.1, but Sections 14 and 15 have been added to cover use of
software over a computer network and provide for limited attribution for the
Original Developer. In addition, Exhibit A has been modified to be consistent
with Exhibit B.

Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
the specific language governing rights and limitations under the License.
------------------------------------------------------------------------
The Original Code is Jcow.

The Original Developer is the Initial Developer.  The Initial Developer of the
Original Code is jcow.net.

\* ############################################################ */

class events extends story{
	public $list_type = 'ul';
	function events() {
		global $nav,$ubase;
		$nav[] = url('events',t('Events'));
		parent::story();
		$this->photos = 1;
		$this->act_write = t('Created an event');
		$this->write_story = t('Create event');
		set_menu_path('events');
	}
	
	function hook_writestory($row) {
		$output = '
		<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
		<script>
		$(document).ready( function(){
			$("#datepicker").datepicker({
				onSelect: function(date, instance) {
						$("#event_date").val(date);
				}
			});

		});

		</script>
		<div style="padding-left:20px">
			<table border="0"><tr><td>
			<div type="text" id="datepicker"></div>
			<input type="hidden" name="date" id="event_date" value="'.date('m/d/Y').'" />
			</td>
			<td valign="top">
							<p>'.label(t('Time')).timeselector().'
							</p>
							<p>
								'.label(t('Location')).'
								<input type="text" name="location" size="40" />
								</p>
			</td>
			</tr>
			</table>
		</div>
		
';
		return $output;
	}
	
	function hook_writestorypost(&$story) {
		global $client;
		
		$timeline = strtotime($_POST['date'].' '.$_POST['time']);
		$story['var1'] = $_POST['location'];
		$story['var2'] = $timeline;
		$uids[] = $client['id'];
		$text1 = serialize($uids);
		$story['text1'] = $text1;
	}
	
	function hook_viewstory($row) {
		button('events/joinit/'.$row['id'],t('I want join'));
		$output .='<p><strong>'.t('Joined members').':</strong><br />';
		$uids = unserialize($row['text1']);

		if (is_array($uids)) {
			foreach ($uids as $uid) {
				$res = sql_query("select username from `".tb()."accounts` where id='$uid'");
				$u = sql_fetch_array($res);
				$output .= url('u/'.$u['username'],$u['username']).' ';
			}
		}
		$output .= '</p>';
		$output .= '
				<p>
				<strong>'.t('Location').':</strong> '.$row['var1'].'
				</p>
				<p>
				<strong>'.t('Time').':</strong> '.get_date($row['var2']).'
				</p>
				';
		return $output;
	}
	
	function joinit($sid) {
		global $client;
		$story = valid_story($sid);
		$uids = unserialize($story['text1']);
		if (is_array($uids)) {
			if (in_array($client['id'],$uids)) {
				sys_back(t('You have joined this event'));
			}
		}
		$uids[] = $client['id'];
		$text1 = serialize($uids);
		sql_query("update `".tb()."stories` set text1='$text1' where id={$story['id']}");
		redirect('events/viewstory/'.$story['id'],t('Opration success'));
	}
	
	function story_form_content($row = array()) {
		return '<p>'.label(t('Description')).'<textarea name="form_content" rows="3" >'.htmlspecialchars($row['content']).'</textarea></p>';
	}

	function ajax_form($page_type='') {
		global $client;
		if (!$client) die('login');
		if ($page_type == 'u' || $_REQUEST['page_type'] == 'u') {
			$privacy_form = privacy_form();
		}
		echo '
				<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
		<script>
		$(document).ready( function(){
			$("#datepicker").datepicker({
				onSelect: function(date, instance) {
						$("#event_date").val(date);
				}
			});

		});

		</script>
		<div style="padding-left:20px">
			<table border="0"><tr><td width="235">
			<div type="text" id="datepicker"></div>
			<input type="hidden" name="date" id="event_date" value="'.date('m/d/Y').'" />
			</td>
			<td valign="top">
			<p>'.label(t('Event title')).'<input type="text" name="event_title" size="20" /></p>
			<p>'.label(t('Description')).'<textarea name="description" style="width:200px;height:50px"></textarea></p>
							<p>'.label(t('Time')).timeselector().'
							</p>
							<p>
								'.label(t('Location')).'
								<input type="text" name="location" size="20" />
								</p>
			</td>
			</tr>
			</table>
		</div>
		<div style="padding-right:25px;text-align:right">
		'.$privacy_form.'</div>';
		exit;
	}

	function ajax_post() {
		global $client;
		if (!$client) die('login');
		if (!$_POST['event_title']) events::ajax_error(t('Please input a Title'));
		$vote_options['rating'] = t('Rating');
		foreach ($vote_options as $key=>$vla) {
			$ratings[$key] = array('score'=>0,'users'=>0);
		}
		$page = story::check_page_access($_POST['page_id']);
		$story = array(
			'cid' => 0,
			'page_id' => $_POST['page_id'],
			'page_type'=>$page['type'],
			'title' => $_POST['event_title'],
			'content' => $_POST['description'],
			'uid' => $client['id'],
			'created' => time(),
			'app' => 'events',
			'var5' => $_POST['privacy'],
			'rating' => serialize($ratings)
			);
		$timeline = strtotime($_POST['date'].' '.$_POST['time']);
		$story['var1'] = $_POST['location'];
		$story['var2'] = $timeline;
		$uids[] = $client['id'];
		$text1 = serialize($uids);
		$story['text1'] = $text1;
		if (sql_insert($story, tb().'stories')) {
			$sid = $story['id'] = mysql_insert_id();
			save_tags($stags,$sid,'events');
			// write act
			$attachment = array(
				'cwall_id' => 'events'.$sid,
				'uri' => 'events/viewstory/'.$sid,
				'name' => $_POST['event_title']
				);
			$app = array('name'=>'events','id'=>$sid);
			$stream_id = stream_publish(t('started an event'),$attachment,$app);
			$set_story['id'] = $sid;
			$set_story['stream_id'] = $stream_id;
			sql_update($set_story,tb()."stories");
			echo t('Event Added!').' 
			<a href="'.url('events/viewstory/'.$sid).'"><strong>'.t('View').'</strong></a>';
		}
		else {
			events::ajax_error('failed to add event');
			
		}
		echo events::ajax_form();
		exit;
	}

	function ajax_error($msg) {
		echo '<div style="color:red">'.$msg.'</div>';
		echo events::ajax_form();
		exit;
	}
}
