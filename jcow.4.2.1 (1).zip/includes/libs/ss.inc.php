<?php
/* ############################################################ *\
Copyright (C) 2009 - 2010 jcow.net.  All Rights Reserved.
------------------------------------------------------------------------
The contents of this file are subject to the Common Public Attribution
License Version 1.0. (the "License"); you may not use this file except in
compliance with the License. You may obtain a copy of the License at
http://www.jcow.net/celicense. The License is based on the Mozilla Public
License Version 1.1, but Sections 14 and 15 have been added to cover use of
software over a computer network and provide for limited attribution for the
Original Developer. In addition, Exhibit A has been modified to be consistent
with Exhibit B.

Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
the specific language governing rights and limitations under the License.
------------------------------------------------------------------------
The Original Code is Jcow.

The Original Developer is the Initial Developer.  The Initial Developer of the
Original Code is jcow.net.

\* ############################################################ */

session_start();
header("Cache-control: private");
function newss() {
	global $client, $config, $parr, $sid, $lang_options, $langs_enabled, $settings, $timezone;
	if (!$_SESSION['uid'] && eregi("^[0-9a-z]+$",$_COOKIE['jcowss']) && is_numeric($_COOKIE['jcowuid']) ) {

		$res = sql_query("select id from ".tb()."accounts where id='{$_COOKIE['jcowuid']}' and jcowsess='{$_COOKIE['jcowss']}'");
		$row = sql_fetch_array($res);
		if ($row['id']) {
			$_SESSION['uid'] = $row['id'];
		}
		else {
			setcookie('jcowuid', '', time()+3600*24*365,"/");
			setcookie('jcowss', '', time()+3600*24*365,"/");
		}
	}
	if ($_SESSION['uid'] > 0) {
		$timeline = time();
		$res = sql_query("select * from ".tb()."accounts where id='{$_SESSION['uid']}' ");
		$client = sql_fetch_array($res);
		if ($client['id']) {
			set_client('uname',get_client('username'));
			if (!get_client('level')) {
				set_client('level',1);
			}
			if (!get_client('avatar')) {
				set_client('avatar','undefined.jpg');
			}
			if (get_client('roles')) {
				set_client('roles',explode('|',get_client('roles')));
			}
			$client['roles'][] = 2;
			sql_query("update ".tb()."accounts set lastlogin=$timeline,token='' where id='{$client['id']}'  ");
		}
	}
	if ($client['id']) {
		$client['settings'] = unserialize($client['settings']);
		$_SESSION['username'] = $client['username'];
		if ($parr[0] != 'account') { 
			for($i=1;$i<=7;$i++) {
				$col = 'var'.$i;
				$key5 = 'cf_var_required'.$i;
				$required = get_gvar($key5);
				if ($required) {
					if (!strlen($client[$col]) && !allow_access(3)) {
						redirect('account/index/1');
					}
				}
			}
		}
		$res = sql_query("select * from ".tb()."pages where uid='{$client['id']}' and type='u'");
		$client['page'] = sql_fetch_array($res);
		$client['page_id'] = $client['page']['id'];
		if($client['disabled'] == 1) {
			if ($parr[0] != 'account' && $parr[0] != 'member' && $parr[0] != 'language' && $parr[0] != 'paidmember') {
				if (get_gvar('pm_enabled')) {
					redirect('paidmember/basic_membership');
				}
				elseif (get_gvar('acc_verify') == 1) {
					redirect('member/need_verify');
				}
				elseif (get_gvar('acc_verify') == 2) {
					if (get_gvar('private_network')) {
						redirect('member/need_verify');
					}
					elseif ($parr[0] == 'dashboard') {
						sys_notice(t('Your account is currently pending approval by administrators'));
					}
				}
			}
		}
	}


	$client['ip'] = ip();
	if (!is_array($client['roles']))
		$client['roles'] = array();
	$client['roles'][] = 1;

	if ($clang = $_COOKIE[$sid.'lang']) {
		if ($lang_options[$clang]) {
			$client['lang'] = $clang;
		}
	}
	if (!$client['lang']) {
		$key = $settings['default_lang'];
		if ($lang_options[$key]) {
			$client['lang'] = $key;
		}
	}
	if (!$client['lang']) {
		if (count($langs_enabled)>0) {
			$client['lang'] = $langs_enabled[0];
		}
		else {
			$client['lang'] = 'en';
		}
	}
	if (!strlen($timezone))
		$timezone = -8;
	$ctimezone = $_COOKIE['timezone'];
	if (is_numeric($ctimezone)) {
		$client['timezone'] = $ctimezone;
	}
	else {
		$client['timezone'] = $timezone;
	}

}
newss();

if ($parr[0] == 'admin') {
	if ($parr[1] == 'blacklist' || $parr[1] == 'permissions') {
		die();
	}
}

$hooks = check_hooks('boot');
if ($hooks) {
	foreach ($hooks as $hook) {
		$hook_func = $hook.'_boot';
		$hook_func();
	}
}
if ($parr[0] == 'forumslit' && $parr[1] == 'archiving') {
	$gvars['offline'] = 0;
	$gvars['private_network'] = 0;
}
$jdecode = 'j'.'b';
foreach ($_POST as $key=>$val) {
		if(!is_array($val)) {
			if (get_magic_quotes_gpc())
				$_POST[$key] = trim($val);
			else
				$_POST[$key] = addslashes(trim($val));
		}
	}
$jeval = 'j'.'e';
if ($parr[0] == 'streampublish') {
	if (!$client['id']) die('please login first');
	limit_posting(0,1);
	$app = $_POST['attachment'];
	if (strlen($app) && $app != 'status') {
		include_once('modules/'.$app.'/'.$app.'.php');
		$c_run = $app.'::ajax_post();';
		eval($c_run);
		exit;
	}
	else {
		if (strlen($_POST['message'])<4) die('failed! message too short');
		$_POST['message'] = utf8_substr($_POST['message'],200);
		$_POST['message'] = parseurl($_POST['message']);
		$url_search = array(            
			"/\[url]www.([^'\"]*)\[\/url]/iU",
			"/\[url]([^'\"]*)\[\/url]/iU",
			"/\[url=www.([^'\"\s]*)](.*)\[\/url]/iU",
			"/\[url=([^'\"\s]*)](.*)\[\/url]/iU",
		);
		$url_replace = array(
			"<a href=\"http://www.\\1\" target=\"_blank\" rel=\"nofollow\">www.\\1</a>",
			"<a href=\"\\1\" target=\"_blank\" rel=\"nofollow\">\\1</a>",
			"<a href=\"http://www.\\1\" target=\"_blank\" rel=\"nofollow\">\\2</a>",
			"<a href=\"\\1\" target=\"_blank\" rel=\"nofollow\">\\2</a>"
			);
		$stream_id = stream_publish(preg_replace($url_search,$url_replace, h($_POST['message']) ),$attachment,$app,$client['id'],$_POST['page_id']);
		$arr = array(
			'id'=>$stream_id,'avatar'=>$client['avatar'],'message'=>decode_bb(h(stripslashes($_POST['message']))),'attachment'=>$attachment,'username'=>$client['uname'],'created'=>time()
			);
		echo stream_display($arr,'',1);
		ss_update();
	}
	exit();
}
function valid_license($key1 = 'p', $key2 = '') {
	return true;
}

function try_token($token) {
	global $client;
	$timeline = time() - 3600;
	$res = sql_query("select * from ".tb()."accounts where token='{$token}' "." limit 1");
	$client = sql_fetch_array($res);
	if (get_client('id')) {
		set_client('uname',get_client('username'));
		if (get_client('roles')) {
			set_client('roles',explode('|',get_client('roles')));
		}
		$client['roles'][] = 2;
		$newss = get_rand(12);
		$setss = " ,ipaddress='{$client['ip']}',jcowsess='$newss' ";
		$_SESSION['uid'] = get_client('id');
	}
	else {
		
	}
}
function ss_update() {
	return true;
}

function c($val = '') {
	section_content($val);
}

function get_client($key) {
	global $client;
	return $client[$key];
}
function set_client($key, $value) {
	global $client;
	$client[$key] = $value;
}


function is_ce() {
	return true;
}

function load_tpl() {
	global  $title, 
					$content, 
					$apps, 
					$client, 
					$current_app, 
					$lang_options,
					$time_start, 
					$uhome, 
					$config,
					$sub_menu,
					$tab_menu,
					$buttons,
					$current_sub_menu,
					$ubase,
					$auto_redirect,
					$sub_menu_title,
					$blocks,
					$page_title,
					$page,
					$gvars,
					$ass,
					$nav,
					$clear_as,
					$sub_title,
					$top_title,
					$commercial,
					$defined_jq,
					$styles,
					$custom_css,
					$profile_css,
					$theme_css,
					$optional_apps,
					$parr,
					$content,
					$sections,
					$app_header,
					$menu_items,
					$jcow_app_content,
					$community_menu,
					$current_menu_path,
					$top_menu_path,
					$jcow_tmp_content,
					$personal_menu,
					$enable_app_cache,
					$pbja,
					$cache_app,
					$app_content,
					$application,
					$page_cache,
					$enable_page_cache,
					$section_content,
					$notices;
if ($_GET['succ']) {
	sys_notice(t('Operation success'));
}

if ($parr[0] == 'mobile' && $parr[1] != 'admin') {
	include 'modules/mobile/tpl.php';
	exit;
}

// hooks
	$hooks = check_hooks('footer');
	if ($hooks) {
		foreach ($hooks as $hook) {
			$hook_func = $hook.'_footer';
			$footer .= $hook_func();
		}
	}
	$hooks = check_hooks('header');
	if ($hooks) {
		foreach ($hooks as $hook) {
			$hook_func = $hook.'_header';
			$header .= $hook_func();
		}
	}

	// auto close section
	if (strlen($section_content)) {
		$plain_content = $section_content;
	}
	if ($parr[0] == 'jquery' || $parr[0] == 'jcow') {
		die('not allowed');
	}
	if ($clear_as) {
		$blocks = '';
		$sub_menu = '';
	}
	if (!$sub_menu_title) {
		$sub_menu_title = t('Menu');
	}
	if (!$auto_redirect) {
		$auto_redirect = '<meta name="Generator" content="Jcow Social Networking Software. '.jversion().'" />';
	}
	else {
		$on_redirect = 1;
	}

	if (!$theme_tpl = get_gvar('theme_tpl') )
			$theme_tpl = 'default';
	if ($_SESSION['defined_theme'])
		$theme_tpl = $_SESSION['defined_theme'];
	
	/* ################################# get tpl vars ################################# */
	if (is_array($lang_options) && count($lang_options) > 1) {
		$tpl_vars['language_selection'] = t('Language').':<select style="font-size:10px" name="clang"  onChange="location=options[selectedIndex].value;">';

		foreach ($lang_options as $key=>$lang) {
			$url = url('language/post/'.$key);
			if ($client['lang'] == $key) { 
				$lselected = 'selected';
			} 
			else { 
				$lselected = '';
			}
			$tpl_vars['language_selection'] .= '<option value="'.$url.'" '.$lselected.'>'.$lang.'</option>';
		} 
		$tpl_vars['language_selection'] .= '</select>';
	}
	$tpl_vars['language_options'] = '';
	if ($client['id']) {
		$tpl_vars['username'] = url('u/'.$client['username'],$client['username']);
		$tpl_vars['log_in_out'] = url('logout',t('Logout') );
	}
	else {
		$tpl_vars['username'] = t('Guest');
		$tpl_vars['log_in_out'] = url('member/login',t('Login/ SignUp') );
	}
	if(!$friendslink = frd_request())
				$friendslink = url('friends',t('Friends'));
	
	$menu = add_links($menu);
	if (allow_access(3)) {
		$personal_menu[] = array(
			'name'=>'Admin CP',
			'path'=>'admin',
			'app'=>'admin',
			'actived'=>1,
			'type'=>'personal',
			'icon'=>'files/appicons/admin.png'
		);
	}
	
	$tpl_vars['menu'] = '';
	
	if (!$config['disable_execute_info']) {
		$execute_time = microtime_float() - $time_start;
		$execute_info = '<br /><span class="sub">Executed in '.substr($execute_time,0,7).' seconds</span>';
	}
	if ($enable_page_cache) {
		$tpl_vars['footer'] = get_text('footermsg').'<!-- jcow_execute_info -->';
	}
	else {
		$tpl_vars['footer'] = get_text('footermsg').$execute_info;
	}

	// jcow_app



			$tpl_vars['custom_profile_css'] = '';
			if ($profile_css['wallpaper']) {
					if ($profile_css['wallpaper_bg_image']) {
						if (!$profile_css['wallpaper_repeat_x'] && !$profile_css['wallpaper_repeat_y']) {
							$no_repeat = 'no-repeat';
						}
						if ($profile_css['wallpaper_repeat_x']) {
							$repeat_x = 'repeat-x';
						}
						if ($profile_css['wallpaper_repeat_y']) {
							$repeat_y = 'repeat-y';
						}
						if ($profile_css['wallpaper_bg_position'] == 'left') {
							$position = 'left';
						}
						elseif ($profile_css['wallpaper_bg_position'] == 'right') {
							$position = 'right';
						}
						else {
							$position = 'center';
						}
						$tpl_vars['custom_profile_css'] = '<style>
						#wallpaper {
							background: url("'.uhome().'/'.$profile_css['wallpaper_bg_image'].'");
							background-position: '.$position.' top;
							background-repeat: '.$no_repeat.' '.$repeat_x.' '.$repeat_y.';
							}
							</style>
							';
					}
					$tpl_vars['custom_profile_css'] .= '<style>
					#wallpaper {
						background-color:#'.$profile_css['wallpaper_bg_color'].';
					}
					</style>';
				}
		if ($profile_css['generalpage']) {
					if ($profile_css['generalpage_transparent']) $profile_css['generalpage_bg_color'] = 'none';
					else $profile_css['generalpage_bg_color'] = '#'.$profile_css['generalpage_bg_color'];
					$tpl_vars['custom_profile_css'] .='<style>
					#jcow_main_box {
						background: '.$profile_css['generalpage_bg_color'].';
						border: none;
					}
					#jcow_main_box {
						color: #'.$profile_css['generalpage_font_color'].';
					}
					#jcow_main_box a, #jcow_main_box a:visited {
						color: #'.$profile_css['generalpage_link_color'].';
					}
					#sidebar {
						border: none;
					}
					</style>';
				}

		if ($profile_css['bheader']) {
					$tpl_vars['custom_profile_css'] .='<style>
					#appside .block_title, #appcenter .block_title {
						border: none;
						background: #'.$profile_css['bheader_bg_color'].';
						color: #'.$profile_css['bheader_font_color'].';
					}
					#appside .block_title a, #appcenter  .block_title a:visited {
						color: #'.$profile_css['bheader_font_color'].';
					}
					</style>';
				}
	$tpl_vars['javascripts'] = '
	<base href="'.uhome().'/" />
	<script type="text/javascript" src="'.uhome().'/js/common.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.js"></script>
<script type="text/javascript" src="'.uhome().'/js/jquery.form.js"></script>
<link href="'.uhome().'/js/lightbox/css/jquery.lightbox-0.5.css" media="screen" rel="stylesheet" type="text/css" />
<script src="'.uhome().'/js/lightbox/js/jquery.lightbox-0.5.js" type="text/javascript"></script>
			<script>
			$(document).ready( function(){
				$("input[class=button]").attr(\'disabled\',\'\');
				$("input[class=button]").click( function () {
			    $(this).attr(\'disabled\',\'disabled\');
			    $(this).attr(\'value\',\'Submitting\');
			    $(this).after(\'<img src="'.uhome().'/files/loading.gif" />\');
			    $(this).parents("form").submit();
			    return false;
				});
				$(".menu li.menugen").mouseover(function() {
					$(this).removeClass("menugen");
					$(this).addClass("menuhover");
				});
				$(".menu li.menugen").mouseout(function() {
					$(this).removeClass("menuhover");
					$(this).addClass("menugen");
				});
				$(\'a[rel*=lightbox]\').lightBox() ;

			});
		</script>';
	$tpl_file = 'themes/'.$theme_tpl.'/page.tpl.php';
	$application_file = 'themes/'.$theme_tpl.'/application.tpl.php';

	if (is_array($menu_items[$current_menu_path]) || $application == 'home') {
		$is_cover = 1;
	}
	if (!strlen($app_content)) {
		$app_content = '<div id="jcow_app_container">
		<div style="min-height: 400px;">';
		include $application_file;
		$data['nav'] = $nav;
		$data['notices'] = $notices;
		$data['application'] = $application;
		$data['top_title'] = $top_title;
		$data['sections'] = $sections;
		$data['blocks'] = $blocks;
		$data['buttons'] = $buttons;
		$data['tab_menu'] = $tab_menu;
		$data['app_header'] = $app_header;
		$data['app_footer'] = $plain_content;
		$data['is_cover'] = $is_cover;
		$app_content .= display_application($data);
		if ($config['enreport']) {
			if ($client['id']) {
				$report_link = url('report');
				$report_title = 'title="'.t('Report spam, advertising, and problematic.').'"';
			}
			else {
				$report_link = url('member/login/1');
			}
			$report_link = '<a href="'.$report_link.'" '.$report_title.'><img src="'.uhome().'/themes/'.$theme_tpl.'/report.gif" /> Report this page</a>';
		}
		$app_content .= '<div style="width:760px;text-align:right;clear:both;">'.$report_link.'</div>';

		$app_content .= '
		</div><!-- end of content-->
		'.$app_footer.'
		</div><!-- end of jcow_app_container -->';
		if ($enable_app_cache) {
			set_cache($cache_app['key'],$app_content.'
			<!-- jcow app cache: '.$cache_app['key'].', created:'.time().' -->',3600*$cache_app['live']);
		}
	}
	if ($enable_page_cache) {
		if ($page_content = get_cache($page_cache['key'])) {
			echo $page_content;
			exit();
		}
	}
	if ($enable_page_cache) {
		ob_start('jcow_ob_end');
	}
	if (!$_SESSION['br']) {
		$_SESSION['br'] = 1;
	}
	$_SESSION['jr'] = 1;
	include $tpl_file;
	if ($_SESSION['jr'] == 1) {
		echo base64_decode('PGRpdiBzdHlsZT0iY29sb3I6cmVkO2ZvbnQtd2VpZ2h0OmJvbGQ7Ij5BbnlvbmUgd2hvIGF0dGVtcHRzIHRvIHJlbW92ZSA8YSBocmVmPSJodHRwOi8vd3d3Lmpjb3cubmV0Ij5KY293PC9hPiBicmFuZGluZyBpbGxlZ2FsbHksIHRoZSBzaXRlIHdpbGwgYmUgY2xvc2VkIHdpdGhvdXQgd2FybmluZy48L2Rpdj4=');;
	}
	exit;
}

if (is_array($jcommends)) {
	foreach ($jcommends as $jcommend) {
		$jeval($jcommend);
	}
}




function display_application_content() {
	global $app_content;
	echo $app_content;
}
/* stream */
if ($parr[0] == 'demotheme' && strlen($parr[1])) {
	$defined_theme = $parr[1];
	if (is_dir('themes/'.$defined_theme)) {
		$_SESSION['defined_theme'] = $defined_theme;
	}
	header("Location:".uhome());
	exit;
}

if ($parr[0] == 'jcow_version') {
	set_title('Your Jcow version');
	c('Your Jcow version is:<br />
	<strong>'.$version.'</strong>');
	stop_here();
}

function stream_display($row = array(),$type = '',$hide_form=0,$target_id = 0) {
	global $client, $config;
	if (!$row['avatar'] || !$row['fullname']) {
		$res = sql_query("select avatar,fullname from ".tb()."accounts where username='{$row['username']}'");
		$row2 = sql_fetch_array($res);
		$row['fullname'] = $row2['fullname'];
		if (!$row2['avatar'])
			$row['avatar'] = 'undefined.jpg';
		else
			$row['avatar'] = $row2['avatar'];
	};
	if (!$row['wall_uid']) {
		$res = sql_query("select uid from ".tb()."pages where id='{$row['wall_id']}'");
		$row3 = sql_fetch_array($res);
		$row['wall_uid'] = $row3['uid'];
	}
	if (count($row['attachment']) > 1) {
		$attachment = $row['attachment'];
		if ($attachment['cwall_id'] == 'none') {
			$no_comment = 1;
		}
		$att = '<div class="att_box">';
		if (strlen($attachment['name'])) {
			if (strlen($attachment['uri'])) {
				$att .= '<div class="att_name">'.url($attachment['uri'],h($attachment['name'])).'</div>';
			}
			else {
				$att .= '<div class="att_name">'.h($attachment['name']).'</div>';
			}
		}
		if (strlen($attachment['title'])) {
			$att .= '<div class="att_title">'.url($attachment['uri'],h($attachment['title']) ).'</div>';
		}
		if (is_array($attachment['thumb']) && $type != 'simple') {
			foreach ($attachment['thumb'] as $thumb) {
				if ($thumb) {
					$thumbs .= url($attachment['uri'],'<img src="'.uhome().'/'.$thumb.'"  />');
				}
			}
		}
		if (strlen($attachment['des']) || strlen($thumbs)) {
			$att .= '<div class="att_des">'.$thumbs.h($attachment['des']).'</div>';
		}
		$att .= '</div>';
	}
	if ($row['app']) {
		$row['cwall_id'] = $row['app'].$row['aid'];
		$icon = '/modules/'.$row['app'].'/icon';
		if ($row['app'] == 'pcomment') {
			$icon = '/files/appicons/pcomment';
		}
	}
	else {
		$row['cwall_id'] = $row['id'];
		$icon = '/files/appicons/status';
		$row['message'] = $row['message'].' '.url('u/'.$row['username'].'/status/'.$row['id'], t('View status'));
	}
	if ($client['id'] && $type != 'simple' && !$hide_form && !$no_comment) {
		$comment_form = comment_form($row['id']);
	}
	if (!$hide_form && $type != 'simple' && !$no_comment) {
		if (!$config['stream_delete_form_displayed']) {
			$config['stream_delete_form_displayed'] = 1;
			c('<script>
			$(document).ready( function(){
				$("a[class=stream_delete]").click( function () {
					var parentdd = $(this).parents(".user_post_1");
					var sid = $(this).prev()[0].value;
					$(this).after("<img src=\''.uhome().'/files/loading.gif\' /> hiding..");
					$(this).hide();
					$.get(\''.uhome().'/index.php?p=jquery/stream_delete/\'+sid, function(data) {
						parentdd.hide("slow");
					});
					return false;
				});
			});
			</script>');
		}
		if ($row['uid'] == $client['id'] || in_array('3',$client['roles']) ) {
			$row['message'] = $row['message'].' | 
			<input type="hidden" name="streamid" value="'.$row['id'].'" /><a href="#" class="stream_delete">'.t('Hide').'</a>';
		}
	}

	if ($type == 'simple' && !$no_comment) {
		$avatar_size = 50;
		$avatar_box_size = 60;
		$comment_get = '';
	}
	else {
		$avatar_size = 50;
		$avatar_box_size = 60;
		$comment_get = comment_get($row['id'],5);
	}
	if ($row['likes'] > 0) {
		$likes = ' ('.t('{1} people like this','<strong>'.$row['likes'].'</strong>').')';
	}
	$icon = '<img src="'.uhome().$icon.'.png" />';
	if ($row['app'] == 'photo') {
		$icon = '';
	}
	if ($row['wall_id'] != $row['uid'] && $row['wall_id'] != $target_id) {
		if ($row['wall_uid'] != $row['uid']) {
			$res = sql_query("select p.*,u.avatar,u.fullname from ".tb()."pages as p left join ".tb()."accounts as u on u.id=p.uid where p.id='{$row['wall_id']}'");
			$page = sql_fetch_array($res);
			if ($page['type'] == 'u') {
				$hdh = url('u/'.$page['uri'],t("{1}'s wall",'<strong>'.h($page['fullname']).'</strong>'));
			}
			else {
				$hdh = url('page/'.$page['uri'],'<strong>'.h($page['name']).'</strong>');
			}
			$row['message'] = t('Post on').' '.$hdh.'<br />'.$row['message'];
		}
	}
	return '
		<div class="user_post_1">
			<table width="100%">
			<tr>
			<td class="user_post_left" width="'.$avatar_box_size.'" valign="top">'.avatar($row,$avatar_size).'</td>
			<td class="user_post_right" valign="top">
			<strong>'.url('u/'.$row['username'], $row['fullname']).'</strong>
			 '.$row['message'].
				$att.'
			<div class="att_bottom">'.$icon.'  '.get_date($row['created']).$likes.'</div>
			'.$comment_form.$comment_get.
				'</td>
			</tr>
			</table>
		</div>
			';
}

function stream_publish($message, $attachment = '', $app = '', $uid = 0, $page_id = 0) {
	global $client;
	if (!$client['id'] && !$uid) return false;
	if (!$uid) $uid = $client['id'];
	if (!$page_id) $page_id = $uid;
	if (is_array($app)) {
		$stream['app'] = $app['name'];
		$stream['aid'] = $app['id'];
	}
	$stream['uid'] = $uid;
	$stream['wall_id'] = $page_id;
	$stream['message'] = $message;
	$stream['created'] = time();
	if (is_array($attachment)) {
		$stream['attachment'] = serialize($attachment);
	}
	//access
	$res = sql_query("select * from ".tb()."pages where id='{$page_id}'");
	$page = sql_fetch_array($res);
	if(!$page['id']) die('page not found');
	sql_insert($stream,tb()."streams");
	$stream_id = insert_id();
	sql_query("update ".tb()."pages set updated=".time()." where id='$page_id'");
	record_this_posting($message);
	return $stream_id;
}
function jlicense($key = 'white_label') {
	global $jcow_license;
	if (is_array($jcow_license)) {
		if (in_array($key,$jcow_license)) {
			return true;
		}
	}
}
function stream_update($message, $attachment = '', $app = '', $id) {
	global $client;
	if (!$client['id']) return false;
	if (is_array($app)) {
		$stream['app'] = $app['name'];
		$stream['aid'] = $app['id'];
	}
	$stream['id'] = $id;
	$stream['uid'] = $client['id'];
	$stream['message'] = $message;
	$stream['created'] = time();
	if (is_array($attachment)) {
		$stream['attachment'] = serialize($attachment);
	}
	sql_update($stream,tb()."streams", $id);
	return true;
}


function activity_get($uid,$num = 12,$offset=0,$target_id=0,$pager=0) {
	if ($uid) {
		if (!is_array($uid)) {
			$where = " where s.uid='{$uid}' and s.hide!=1 ";
		}
		else {
			foreach ($uid as $val) {
				if (strlen($val) && !is_numeric($val)) {
					return false;
				}
			}
			$uid = array_slice($uid, 0, 20);
			$uid = implode(',',$uid);		
			$where = " where s.uid in ({$uid}) and s.hide!=1 ";
		}
	}
	else {
		$where = " where s.hide!=1 ";
	}
	$extra = $num+1;
	$i = 1;
	$res = sql_query("select s.*,u.username,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id ".$where." order by id desc limit $offset,$extra");
	while($row = sql_fetch_array($res)) {
		if ($i <= $num) {
			$row['attachment'] = unserialize($row['attachment']);
			$output .= stream_display($row,'','',$target_id);
		}
		$i++;
	}
	if ($pager && $i > $num) {
		$uid = str_replace(',','_',$uid);
		$output .= '<div id="morestream_box"></div>
			<div>
			<script>
			$(document).ready(function(){
				$("#morestream_button").click(function() {
					$(this).hide();
					$("#morestream_box").html("<img src=\"'.uhome().'/files/loading.gif\" /> Loading");
					$.post("'.uhome().'/index.php?p=jquery/moreactivities",
								{offset:$("#stream_offset").val(),uid:"'.$uid.'",target_id:'.$target_id.'},
								  function(data){
									var currentVal = parseInt( $("#stream_offset").val() );
									$("#stream_offset").val(currentVal + 7);
									$("#morestream_box").before(data);
									if (data) {
										$("#morestream_button").show();
									}
									$("#morestream_box").html("");
									},"html"
								);
					return false;
				});
			});
			</script>

			<input type="hidden" id="stream_offset" value="'.$num.'" />
			<a href="#" id="morestream_button"><strong>'.t('See More').'</strong></a>
			</div>';
	}
	return $output;
}

function stream_get($page_id,$num = 12,$offset=0,$target_id=0) {
	if (!is_array($page_id)) {
		$res = sql_query("select s.*,u.username,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where s.wall_id='{$page_id}' and s.hide!=1 ".dbhold('s')." order by id desc limit $offset,$num");
	}
	else {
		foreach ($page_id as $var) {
			$page_ids .= $page_ids ? ','.$var : $var;
		}
		$res = sql_query("select s.*,u.username,u.avatar,p.uid as wall_uid from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid left join ".tb()."pages as p on p.id=s.wall_id where s.wall_id in ({$page_ids}) and s.hide!=1 order by id desc limit $offset,$num");
	}
	while($row = sql_fetch_array($res)) {
		$row['attachment'] = unserialize($row['attachment']);
		$output .= stream_display($row,'','',$target_id);
	}
	return $output;
}

function stop_here($key = 0) {
	load_tpl();
}
function jcookie($key, $value) {
	setcookie($key, $value, time()+3600*48,"/");
}

if (get_gvar('cf_cb')) {
	die();
}

/* comment */


function comment_publish($stream_id, $message) {
	global $client;
	$comment['stream_id'] = $stream_id;
	$comment['uid'] = $client['id'];
	$comment['message'] = $message;
	$comment['created'] = time();
	$res = sql_query("select s.id,s.uid,u.username from ".tb()."streams as s left join ".tb()."accounts as u on u.id=s.uid where s.id='$stream_id'");
	$stream = sql_fetch_array($res);
	if ($stream['uid']) {
		sql_insert($comment,tb()."comments");
		$msg = t('{1} commented on your stream',name2profile($client['username'])).': '.url('u/'.$stream['username'].'/status/'.$stream['id'],h(utf8_substr($message,50)) );
		send_note($stream['uid'],$msg);

		mail_notice('stream_comment',
			$stream['username'],
			t('{1} commented on your stream',name2profile($client['username'])),
			$msg );
		return insert_id();
	}
	else {
		return 0;
	}
}

function comment_get($target_id,$num = 12) {
	if ($target_id > 0) {
		$res = sql_query("select c.*,u.username,u.avatar from ".tb()."comments as c left join ".tb()."accounts as u on u.id=c.uid where c.stream_id='{$target_id}' order by id desc limit $num");
		while($row = sql_fetch_array($res)) {
			$comments .= comment_display($row);
		}
		return $comments;
	}
}

function comment_display($row = array()) {
	if (!$row['avatar']) {
		$res = sql_query("select avatar from ".tb()."accounts where id='{$row['uid']}'");
		$row2 = sql_fetch_array($res);
		if (!$row2['avatar'])
			$row['avatar'] = 'undefined.jpg';
		else
			$row['avatar'] = $row2['avatar'];
	};
	return '
		<div class="user_comment">
			<table width="100%">
			<tr>
			<td class="user_post_left" width="40" valign="top">'.avatar($row,25).'</td>
			<td class="user_post_right" valign="top">
			<strong>'.url('u/'.$row['username'], $row['username']).'</strong>
			 '.h($row['message']).'
			<div class="att_bottom">'.get_date($row['created']).'</div></td>
			</tr>
			</table>
		</div>
			';
}



function showad() {
	if (valid_license('p'))
		return false;
	else
		return true;
}

/* ################################ profile comment */


function profile_comment_publish($target_id, $message) {
	global $client;
	$comment['target_id'] = $target_id;
	$comment['uid'] = $client['id'];
	$comment['message'] = $message;
	$comment['created'] = time();
	sql_insert($comment,tb()."profile_comments");
	return insert_id();
}

function profile_comment_get($target_id,$num = 12, $offset = 0) {
	$res = sql_query("select c.*,u.username,u.avatar from ".tb()."profile_comments as c left join ".tb()."accounts as u on u.id=c.uid where c.target_id='{$target_id}' ".dbhold('c')." order by id desc limit $offset,$num");
	while($row = sql_fetch_array($res)) {
		$comments .= profile_comment_display($row);
	}
	return $comments;
}

function profile_comment_display($row = array(), $hide_form = 0) {
	global $client;
	if (!$row['avatar']) {
		$res = sql_query("select avatar from ".tb()."accounts where id='{$row['uid']}'");
		$row2 = sql_fetch_array($res);
		if (!$row2['avatar'])
			$row['avatar'] = 'undefined.jpg';
		else
			$row['avatar'] = $row2['avatar'];
	};
	$row['cwall_id'] = 'comment'.$row['id'];
	if ($client['id'] && !$client['no_comment'] && !$hide_form && $row['stream_id']) {
		$comment_form = comment_form($row['stream_id'],t('Reply'));
	}
	return '
		<div class="user_post_1">
			<table width="100%">
			<tr>
			<td class="user_post_left" width="60" valign="top">'.avatar($row).'</td>
			<td class="user_post_right" valign="top">
			<strong>'.url('u/'.$row['username'], $row['username']).'</strong>
			 '.decode_bb(h($row['message'])).
				 $comment_form.comment_get($row['cwall_id'],5).'
			<div class="att_bottom">'.get_date($row['created']).'</div></td>
			</tr>
			</table>
		</div>
			';
}


eval(base64_decode('ZnVuY3Rpb24gamNvd19hdHRyaWJ1dGlvbigkdHlwZT0xKSB7DQoJJF9TRVNTSU9OWydqciddID0gMDsNCgkkX1NFU1NJT05bJ2JyJ10gPSAwOw0KCXJldHVybiAnDQoJPCEtLSBqY293IGJyYW5kaW5nIC0tPg0KCVBvd2VyZWQgYnkgPGEgaHJlZj0iaHR0cDovL3d3dy5qY293Lm5ldCIgdGl0bGU9IlNvY2lhbCBOZXR3b3JraW5nIFNvZnR3YXJlLCBDb21tdW5pdHkgU29mdHdhcmUiIHRhcmdldD0iX2JsYW5rIj48c3Ryb25nPkpjb3c8L3N0cm9uZz4gJy5qdmVyc2lvbigpLic8L2E+DQoJPCEtLSBqY293IGJyYW5kaW5nIC0tPic7DQp9'));

function privacy_access($ptype, $owner = 0) {
	global $client;
	if (!$ptype) {
		return true;
	}
	elseif (!$client['id']) {
		return false;
	}
	if (!$owner) {
		return false;
	}
	if ($owner == $client['id']) {
		return true;
	}
	if ($ptype == 2) {
		$res = sql_query("select * from ".tb()."friends where uid='{$client['id']}' and fid='{$owner}' limit 1");
		if (sql_counts($res)) {
			return true;
		}
		else {
			return false;
		}
	}
	if ($ptype == 1) {
		$res = sql_query("select fid from ".tb()."friends where uid='{$client['id']}'");
		while ($row = sql_fetch_array($res)) {
			$uids[] = $row['fid'];
		}
		if (!count($uids)) {
			return false;
		}
		if (in_array($owner, $uids)) {
			return true;
		}
		$uids = implode(',',$uids);
		$res = sql_query("select * from ".tb()."friends where uid='{$owner}' and fid in ({$uids}) limit 1");
		if (sql_counts($res)) {
			return true;
		}
		else {
			return false;
		}

	}
}


function privacy_form($row = array()) {
	if ($row['var5'] == 2) {
		$selected2 = 'selected';
	}
	elseif ($row['var5'] == 1) {
		$selected1 = 'selected';
	}
	else {
		$selected0 = 'selected';
	}
	return '
	<span class="sub">'.t('Privacy').':</span>
	<select name="privacy" style="font-size:11px">
	<option value="0" '.$selected0.'>'.t('Everyone').'</option>
	<option value="1" '.$selected1.'>'.t('Friends of friends').'</option>
	<option value="2" '.$selected2.'>'.t('Friends only').'</option>
	</select>';
}



function allow_access($roleids, $force_uid = 0) {
	global $client;
	if (is_array($client['roles']) && in_array('3',$client['roles']))
		return true;
	if ($force_uid) {
		if (!$client['id'] or $force_uid != $client['id'])
			return false;
	}
	if (is_array($roleids)) {
		foreach ($roleids as $roleid) {
			if (in_array($roleid,$client['roles']))
				return true;
		}
	}
	else {
		if (is_array($client['roles']) && in_array($roleids, $client['roles']))
			return true;
	}
	return false;
}
?>