INSTALLATION:
Install.txt

OFFICIAL WEBSITE:
http://www.jcow.net

FAQ:
http://www.jcow.net/docs/?s=faq

DOCUMENTATION:
http://www.jcow.net/docs/

LICENSE:
http://www.jcow.net/celicense/

COMMUNITY:
http://community.jcow.net