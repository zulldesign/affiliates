<?php
/* ############################################################ *\
Copyright (C) 2009 - 2010 jcow.net.  All Rights Reserved.
------------------------------------------------------------------------
The contents of this file are subject to the Common Public Attribution
License Version 1.0. (the "License"); you may not use this file except in
compliance with the License. You may obtain a copy of the License at
http://www.jcow.net/celicense. The License is based on the Mozilla Public
License Version 1.1, but Sections 14 and 15 have been added to cover use of
software over a computer network and provide for limited attribution for the
Original Developer. In addition, Exhibit A has been modified to be consistent
with Exhibit B.

Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
the specific language governing rights and limitations under the License.
------------------------------------------------------------------------
The Original Code is Jcow.

The Original Developer is the Initial Developer.  The Initial Developer of the
Original Code is jcow.net.

\* ############################################################ */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">	

<head>
<base href="<?=uhome()?>/" />
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="Generator" content="Powered by Jcow" />
<?=$auto_redirect?>
<style type="text/css" media="all">@import "<?php echo $uhome;?>/files/common_css/style.css";</style>
<style type="text/css" media="all">@import "<?php echo $uhome;?>/themes/facebook/page.css";</style>
<link rel="shortcut icon" href="<?=$uhome;?>/themes/facebook/ico.gif" type="image/x-icon" />
<?=$tpl_vars['javascripts'];?>
<title><?=$title?> - <?=get_gvar('site_name')?></title>
<?=$tpl_vars['custom_profile_css']?>
<?php
if (strlen(get_gvar('site_keywords'))) {
	echo '<meta name="keywords" content="'.get_gvar('site_keywords').'" />';
}
?>
<?=$header?>
</head>

<body>
<div id="topbar_box">
<div id="topbar">
<table width="100%" height="50" cellpadding="0" cellspacing="0"><tr>
<td width="150" valign="bottom">
<?php
if ($client['id']) {
	$home = url('dashboard');
}
else {
	$home = uhome();
}
echo '<a href="'.$home.'"><img src="'.uhome().'/themes/facebook/logo.png" /></a>';
?>

</td>
<td valign="bottom">
	<table  cellpadding="0" cellspacing="0">
	<form action="<?=url('search/listing')?>" method="post" name="search_form">
	<tr>
	<td valign="top">
	<input type="text" id="search_box" name="title" value="" name="search_box"  />
	</td>
	<td>
	<input type="submit" value="find" id="search_button" style="display:none" />
	</td>
	</tr>
	</form>
	</table>
</td>
<?php
if (!$client['id']) {
	echo '
	<td>
	<div id="fblogin"  align="right">
	<table  cellpadding="2" cellspacing="0">
	<form method="post" name="loginform" id="form1" action="'.url('member/loginpost').'" >
	<tr><td>'.t('Username or Email').'</td><td>'.t('Password').'</td></tr>
	<tr><td><input type="text" size="10" name="username" style="width:120px" /></td><td>
		<input type="password" size="10" name="password" style="width:120px" /> 
		<input type="submit" value=" '.t('Login').' " /></td></tr>
	<tr><td><input type="checkbox" name="remember_me" value="1" /> <span style="color:#89A0D1">'.t('Remember me').'</span></td>
		<td>'.url('member/chpass',t('Forgot password?')).'</td></tr>
	</form>
	</table>
	</div>
	</td>';
}
else {
	echo '
	<td valign="bottom" align="right">'.url('u/'.$client['uname'],t('Profile')).' | '.$friendslink.' | '.url('message',t('Inbox').msg_unread() ).' | '.url('notifications',t('Notifications').note_unread()).' | '.url('account',t('Account')).' | <span class="sub">'.url('member/logout',t('Logout') ).'</span>
	</td>';
}
?>
</tr>
</table>

<div id="jcow_community_menu">
<ul class="menu">
<?php
echo '<li '.check_menu_on('home/index').'>'.url(uhome(),t('Home')).'</li>';
if (is_array($community_menu)) {
	foreach ($community_menu as $item) {
		echo '<li '.check_menu_on($item['path']).'>'.url($item['path'],t($item['name'])).'</li>';
	}
}
?>
</ul>
</div>

</div>
</div>


<!-- #################### structure ################## -->

<div id="wallpaper" style="width:100%;height:100%;overflow:hidden">
<div id="jcow_main_box">
<div id="jcow_main">
<table id="appframe" cellspacing="0"><tr>
<?php
if ($is_cover) {

	if($client['id']) {
		echo '<td valign="top" id="menubar_td">
		<div id="menubar">';
		echo '<ul id="sidebarmenu">';
		if (is_array($personal_menu)) {
			foreach ($personal_menu as $item) {
				if ($item['path'] != 'account') {
					echo '<li '.check_menu_on($item['path']).' >'.url($item['path'],
					'<div style="padding:3px 0 3px 23px;background:url('.uhome().'/modules/'.$item['app'].'/icon.png) 0 1px no-repeat">'.t($item['name']).'</div>'
					).'</li>';
				}
			}
		}
		echo '</ul>';
		echo get_gvar('theme_block_lsidebar');
		echo '</div>';
		echo '</td>';
	}

}

echo '<td valign="top">';
if (count($nav) > 2) {
	echo '<div id="nav">'.gen_nav($nav).'</div>';
}
if (is_array($notices)) {
	foreach ($notices as $notice) {
		echo '<div class="notice">'.$notice.'</div>';
	}
}
if ($top_title) {
	echo '<div style="padding:3px 0 3px 30px;background:url('.uhome().'/modules/'.$application.'/icon.png) 9px 5px no-repeat;font-size:1.5em">'.$top_title.'</div>';
}

echo $app_header;
if (is_array($tab_menu)) {
	echo '<div id="tabmenu">';
	echo '<ul>';
	echo '<li class="tm_begin"></li>';
	echo tabmenu_begin();
	foreach ($tab_menu as $item) {
		echo '<li '.check_tabmenu_on($item['path']).'>'.url($item['path'],t($item['name'])).'</li>';
	}
	echo '<li class="tm_end"> </li>';
	echo '</ul>
	</div>';
}

if (is_array($buttons)) {
		echo '<div style="padding-left:10px;"><ul class="buttons">';
		foreach ($buttons as $val) {
			echo '<li>'.$val.'</li>';
		}
		echo '</ul></div>';
	}

/* 
The "display_application_content" is the output of applications. 
The default Width is 780px. 
You may not change the Width, otherwise some applications can not be displayed correctly 
*/
echo '<table border="0" width="100%">
<tr><td valign="top">';
if ($application != 'home') {
	display_application_content();
}
else {
	if (!$client['id']) {
		echo '
				<style>
		body {
			background: url("themes/facebook/home_bg.jpg") top repeat-x;
		}
		</style><table>
		<tr><td valign="top" width="60%">
		<a href="'.url('member/signup').'"><img src="'.uhome().'/themes/facebook/welcome.jpg" alt="welcome" /></a>
		</td>
		<td valign="top">
		<h2>'.t('Sign up').'</h2>
			<form method="post" action="'.url('member/signup').'" >
		

					<p>
					
					'.label(t('Email Address')).'
					<input type="text" size="20" name="email"   class="fpost" style="width:180px" />
					<br /><span class="sub">('.$invite_msg.t("We won't display your Email Address.").')</span>
					</p>

					<p>
					'.label(t('Username')).'
					<input type="text" size="18" class="fpost" name="username" value="'.$_POST['username'].'" style="width:180px" /><br />
					<span class="sub">('.t('4 to 18 characters, made up of 0-9,a-z').')</span>
					</p>

					<p>
					'.label(t('Full Name')).'
					<input type="text" size="20" name="fullname"  class="fpost" style="width:180px" />
					</p>
						<p>
					'.label(t('Come from')).'
					<select name="location" class="inputText">';
					$locations = explode("\r\n",get_text('locations'));
					foreach($locations as $location) {
						if ($_GET['location'] == trim($location)) {
							$selected = 'selected';
						}
						else {
							$selected = '';
						}
						echo '<option value="'.$location.'" '.$selected.' >'.$location.'</option>';
					}
					echo '</select>
					</p>
			<p>
			<input type="hidden" name="g" value="'.$_REQUEST['g'].'" />
						<input type="submit" style="background:#5BA239;color:white;font-size:1.5em;font-weight:bold" value="'.t('Sign up').'" />
						</p>


						
						
			</div>
			</div>
			</form>
		</td>
		</tr>
		</table>
		<div style="height:150px"></div>';
	}
	else {
		echo '
		<script type="text/javascript" src="'.uhome().'/js/jquery.vtricker.js"></script>
		<script>
		jQuery(document).ready(function($) {
			$(\'#recent_activites\').vTicker({
		   speed: 800,
		   pause: 5000,
		   showItems: 4,
		   animation: \'fade\',
		   mousePause: false,
		   height: 350,
		   direction: \'down\'
		});
				});
	</script>
	<style>
	#recent_activites li{
		margin:0;
		padding:0;
		}
	</style>
	<strong>'.t('Community activities').'</strong>
	<div id="recent_activites">
	<ul>
	';
	$res = sql_query("SELECT s.*,u.username,u.avatar from `".tb()."streams` as s left join ".tb()."accounts as u on u.id=s.uid where s.hide!=1  order by s.id desc limit 20");
	while ($stream = sql_fetch_array($res)) {
		$stream['attachment'] = unserialize($stream['attachment']);
		echo '<li>'.stream_display($stream,'simple').'</li>';
	}
	echo '</ul>
	<div style="position:absolute;left:0;bottom:0px;height:20px;width:100%;background:url('.uhome().'/files/common_css/fade.png) repeat-x"> </div></div>';
	}
}
echo '</td>';
if (!$is_cover) {
	echo '<td valign="top"><div style="width:170px;float:right;">
	'.get_gvar('theme_block_adsbar').'</div></td>';
}

echo '
</tr></table>

</td>';


?>


</table>


</div><!-- end jcow_application -->
</div><!-- end jcow_application_box -->
</div><!-- end wallpaper -->

<div id="footer">
<div>
<?=$tpl_vars['language_selection']?>
</div>
<?=$tpl_vars['footer']?>
<br /><br />
<!-- do NOT remove the Jcow Attribution Information -->
<!-- You have 3 style options:jcow_attribution(1), jcow_attribution(2), and jcow_attribution(3) -->
<?=jcow_attribution(1);?>

</div>

<?=$footer;?>
</body>
</html>