<?php
$theme_blocks['lsidebar'] = array(
		'name'=>'Left sidebar',
		'description'=>'Under the left sidebar(Recommended width:150px, recommended height:200px)',
		'default_value'=>''
		);

$theme_blocks['sidebar'] = array(
		'name'=>'Sidebar',
		'description'=>'Under the sidebar (Recommended width:200px)',
		'default_value' => ''
		);

$theme_blocks['adsbar'] = array(
		'name'=>'Ads bar',
		'description'=>'The right sidebar (Recommended width:160px)',
		'default_value'=>'ads'
		);