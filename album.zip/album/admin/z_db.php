<?php
$con = new mysqli("sql202.epizy.com", "epiz_23100669", "ipofhost769", "epiz_23100669_769");
if ($con->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
?>